package com.image.controller;

import java.sql.Connection;
import java.sql.DriverManager;

public class Dataconnection {
	static Connection con=null;
public 	static Connection getConnection ()
{
	try {
	Class.forName("com.mysql.jdbc.Driver");
	con=DriverManager.getConnection("jdbc:mysql://localhost:3306/assignmentdatabase","root","root");
	}catch(Exception e) {
		System.out.println(e);
		
	}
	return con;
}

}
